<?php
include 'includes/class-autoloader.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>MediaBazaar-Schedule</title>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" type="image/x-icon" href="images/sh_icon.ico" />
        <link rel="stylesheet" href="main.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Bangers&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet" />
    </head>
    <body>
        <div class="backdrop"></div>
        <?php include 'includes/main-navigation.php'; ?>
        <section class="schedule-content">
            <form action="" method="post" class="schedule-form">
                <input type="date" name="date-picker-schedule" id="dp-schedule" />
                <input type="submit" value="Show schedule" name="btn-schedule-date" class="btn-submit-schedule-date" />
            </form>
            <div class="schedule-table">
                <div class="mo-wrapper day-wrapper">
                    <div class="mo-head day-head"><p>Monday</p></div>
                    <div class="mo-cell day-cell">
                        <span class="morning-shift">
                            <p>
                                Morning<br />
                                08:00AM-12:30PM
                            </p>
                        </span>
                        <span class="afternoon-shift">
                            <p>
                                Afternoon<br />
                                12:30PM-17:00PM
                            </p>
                        </span>
                    </div>
                </div>
                <div class="tu-wrapper day-wrapper">
                    <div class="tu-head day-head"><p>Tuesday</p></div>
                    <div class="tu-cell day-cell"></div>
                </div>
                <div class="we-wrapper day-wrapper">
                    <div class="we-head day-head"><p>Wednesday</p></div>
                    <div class="we-cell day-cell">
                        <span class="afternoon-shift">
                            <p>
                                Afternoon<br />
                                12:30PM-17:00PM
                            </p>
                        </span>
                        <span class="evening-shift">
                            <p>
                                Evening<br />
                                17:00PM-21:30PM
                            </p>
                        </span>
                    </div>
                </div>
                <div class="th-wrappe day-wrapper">
                    <div class="th-head day-head"><p>Thursday</p></div>
                    <div class="th-cell day-cell"></div>
                </div>
                <div class="fr-wrapper day-wrapper">
                    <div class="fr-head day-head"><p>Friday</p></div>
                    <div class="fr-cell day-cell"></div>
                </div>
                <div class="sa-wrapper day-wrapper">
                    <div class="sa-head day-head"><p>Saturday</p></div>
                    <div class="sa-cell day-cell"></div>
                </div>
                <div class="su-wrapper day-wrapper">
                    <div class="su-head day-head"><p>Sunday</p></div>
                    <div class="su-cell day-cell"></div>
                </div>
            </div>
            <button onclick="topFunction()" id="goTop-btn" title="Go to top"><i class="fas fa-arrow-up"></i>Top</button>
        </section>
        <?php include 'includes/main-footer.php'; ?>
        <script src="js/shared.js"></script>
    </body>
</html>