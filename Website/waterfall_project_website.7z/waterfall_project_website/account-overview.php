<?php
include 'includes/class-autoloader.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>MediaBazaar-Account-Page</title>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" type="image/x-icon" href="images/sh_icon.ico" />
        <link rel="stylesheet" href="main.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Bangers&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet" />
    </head>
    <body>
        <div class="backdrop"></div>
        <?php include 'includes/main-navigation.php'; ?>
        <section class="account-view-content">
            <div class="user-card-wrapper">
                <div class="user-card-header">
                    <i class="fas fa-user-cog"></i>
                </div>
                <div class="user-card-body">
                    <p class="user-card-textinfo">
                        User Id: 23 <br>
                        Username: bop <br>
                        Password: bop1 <br>
                        Phone nr: 316-1234-5678 <br>
                        Adress: Bad Street<br>
                        Email: bopbop@mail.com
                    </p>
                    <a href="account-edit.php" class="user-edit-btn"><i class="fas fa-user-edit"></i>Edit info</a>
                </div>
            </div>
        </section>
        <?php include 'includes/main-footer.php'; ?>
        <script src="js/shared.js"></script>
    </body>
</html>