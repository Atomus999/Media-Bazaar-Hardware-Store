<?php
include 'includes/class-autoloader.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>MediaBazaar-Account-Page</title>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" type="image/x-icon" href="images/sh_icon.ico" />
        <link rel="stylesheet" href="main.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Bangers&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet" />
    </head>
    <body>
    <div class="backdrop"></div>
    <?php include 'includes/main-navigation.php'; ?>
    <section class="account-edit-content">
        <div class="user-edit-card-wrapper">
            <div class="user-card-header">
                <i class="fas fa-user-edit"></i>
            </div>
            <div class="user-card-body">
                <form action="handlers/user-edit-handler.php" method="post" class="user-edit-info-form">
                    <div class="user-edit-text-input-wrap">
                        <b>Username:</b>
                        <input class="edit-username user-edit-text-input" type="text" name="input-edit-username" placeholder="" required />
                    </div>
                    <div class="user-edit-text-input-wrap">
                        <b>Password:</b>
                        <input class="edit-password user-edit-text-input" type="text" name="input-edit-password" placeholder="" required />
                    </div>
                    <div class="user-edit-text-input-wrap">
                        <b>Phone Nr:</b>
                        <input class="edit-phone user-edit-text-input" type="text" name="input-edit-phone" placeholder="" pattern="316-[0-9]{4}-[0-9]{4}$" title="Phone number required format is 316-xxxx-xxxx" required />
                    </div>
                    <div class="user-edit-text-input-wrap">
                        <b>Adress:</b>
                        <input class="edit-adress user-edit-text-input" type="text" name="input-edit-adress" placeholder="" required />
                    </div>
                    <div class="user-edit-text-input-wrap">
                        <b>Email:</b>
                        <input class="edit-email user-edit-text-input" type="email" name="input-edit-email" placeholder="" required />
                    </div>
                    <div class="user-edit-form-btn-wrapper">
                        <a href="account-overview.php" class="user-edit-btn">Cancel</a>
                        <input type="submit" value="Submit" class="user-edit-submit-btn" />
                    </div>
                </form>
            </div>
        </div>
    </section>
    <?php include 'includes/main-footer.php'; ?>
    <script src="js/shared.js"></script>
</body>
</html>