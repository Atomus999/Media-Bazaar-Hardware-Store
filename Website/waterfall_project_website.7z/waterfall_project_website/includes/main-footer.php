<footer class="main-footer">
            <div class="social-feature-list">
                    <div class="footer-text-container">
                        <p>Powered by Study: Proto</p>
                    </div>
            </div>
</footer>